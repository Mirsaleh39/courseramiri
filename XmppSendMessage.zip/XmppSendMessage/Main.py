import requests
import time

MESSAGE_COUNT = 10000
FROM = "+994512704449"
TO = "+994503932078"
MESSAGE = "qwerty355"
# URL = 'http://10.2.56.5:5281/api/send_stanza'
URL = 'https://seda-api.a2z.az/proxy/api/send_stanza'
HEADERS = {
    'Content-Type': 'application/json',
    'Authorization': 'Basic Kzk5NDUxMjcwNDQ0OUB0dXJuMDE6MTIzNDU2Nzg='
}


def get_current_timestamp():
    return str(int(time.time() * 1000))


success_count = 0
fail_count = 0

for i in range(MESSAGE_COUNT):
    data = {
        "from": FROM + "@turn01",
        "to": TO + "@turn01",
        "stanza": f"<message type='chat'><body>{{\"cryptoMethodParam\":null,\"date\":\"{get_current_timestamp()}\",\"from\":\"{FROM}\",\"to\":\"{TO}\",\"messageId\":\"{get_current_timestamp()}_{i}\",\"msg\":\"{MESSAGE}_{i + 1}\"}}</body></message>"
    }

    response = requests.post(URL, headers=HEADERS, json=data)

    if response.status_code == 200:
        success_count += 1
    else:
        fail_count += 1

    print(f"\rProcessed: {i + 1}/{MESSAGE_COUNT} | SUCCESS: {success_count} | FAIL: {fail_count}", end='')
    print("\n")
