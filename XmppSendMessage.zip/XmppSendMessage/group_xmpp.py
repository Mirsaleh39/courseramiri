import xmpp
import json
import time

MESSAGE_COUNT = 20000
MESSAGE = "elshadTest_35"
# TO = "6717836ee4954b38af817b19" #Test Qrup
TO = "1735120354849_room"  # Test Qrup 2
FROM = "+994512704449"
PASSWORD = "12345678"
HOST = "seda-xmpp.a2z.az"
PORT = 5222
DOMAIN = "turn01"


def get_current_timestamp():
    return str(int(time.time() * 1000))


success_count = 0
fail_count = 0

for i in range(MESSAGE_COUNT):
    if i % 100 == 0:
        client = xmpp.Client(DOMAIN, debug=[])
        connection = client.connect(server=(HOST, PORT))

        if not connection:
            exit(0)

        auth = client.auth(FROM, PASSWORD, 'Python')
        if not auth:
            print("Autentifikasiya uğursuz oldu!")
            exit(0)

        room_jid = f"{TO}@conference.{DOMAIN}/Python"
        client.send(xmpp.Presence(to=room_jid))

    json_data = {
        "cryptoMethodParam": None,
        "date": f"{get_current_timestamp()}",
        "msg": f"{MESSAGE}_{i + 1}",
        "messageId": f"{get_current_timestamp()}_{i}",
        "to": TO,
        "from": FROM,
        "conversationType": "group"
    }

    message_body = json.dumps(json_data)
    msg = xmpp.Message(TO + "@conference." + DOMAIN, message_body)
    msg.setAttr('type', 'groupchat')
    res = client.send(msg)

    if res:
        success_count += 1
    else:
        fail_count += 1

    print(f"\rProcessed: {i + 1}/{MESSAGE_COUNT} | SUCCESS: {success_count} | FAIL: {fail_count}", end='')
    time.sleep(0.05)

client.Process(1)
client.disconnect()
