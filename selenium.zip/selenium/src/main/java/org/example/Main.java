package org.example;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Main {

//    private static AndroidDriver<MobileElement> driver;
//
//    public static void main(String[] args) throws MalformedURLException {
//
//        // Настройка DesiredCapabilities
//        DesiredCapabilities caps = new DesiredCapabilities();
//        caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
//        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "RZCTB1B44MY"); // Или имя вашего устройства
//        caps.setCapability(MobileCapabilityType.APP, "/path/to/your/app.apk"); // Путь к вашему приложению
//        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
//
//        // Инициализация драйвера
//        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), caps);
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//
//        // Вызов метода message
//        Main main = new Main();
//        main.message();
//    }
//
//    public void message() {
//        driver.findElementById("az.a2z.enigma.v2:id/fab_new_chat").click();
//
//        String chatName = "Nesir Test79";
//
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
//        driver.findElementByXPath("//android.widget.TextView[@resource-id=\"az.a2z.enigma.v2:id/chatProfileName\" and @text=\"" + chatName + "\"]").click();
//
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1));
//        MobileElement messageBox = driver.findElementById("az.a2z.enigma.v2:id/editTextMessage");
//
//        for (int i = 1; i <= 3; i++) {
//            messageBox.sendKeys(Integer.toString(i));
//            driver.findElementById("az.a2z.enigma.v2:id/imageViewSend").click();
//        }
//    }
}
