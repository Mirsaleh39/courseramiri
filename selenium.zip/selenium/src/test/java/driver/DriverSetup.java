package driver;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;

public class DriverSetup {

    public static AndroidDriver getDriver(String deviceName, String udid) throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("deviceName", deviceName);
        caps.setCapability("udid", udid);
        caps.setCapability("platformName", "Android");
        caps.setCapability("platformVersion", "14");
        caps.setCapability("automationName","UiAutomator2");
        caps.setCapability("appPackage", "az.a2z.enigma.v2");
        caps.setCapability("appActivity", "az.a2z.enigma.SingleActivity");
        caps.setCapability("noReset","true");

        URL sedaURL = new URL("http://127.0.0.1:4723/");
        return new AndroidDriver(sedaURL, caps);
    }
}
