package stepDefinitions;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.MalformedURLException;
import java.time.Duration;

import driver.DriverSetup;

import javax.swing.*;

import static java.lang.Thread.sleep;

public class CallDefinitions {

    private AndroidDriver realDeviceDriver1;
    private AndroidDriver realDeviceDriver2;
    public WebDriverWait wait1;
    public WebDriverWait wait2;

    @Given("enter the app")
    public void enterTheApp() throws MalformedURLException {
        realDeviceDriver1 = DriverSetup.getDriver("Galaxy A33 5G", "RZCTB1B44MY");
        wait1 = new WebDriverWait(realDeviceDriver1, Duration.ofSeconds(15));

        realDeviceDriver2 = DriverSetup.getDriver("Galaxy A33 5G", "RZCTB1B4B8K");
        wait2 = new WebDriverWait(realDeviceDriver2, Duration.ofSeconds(15));

        ExtentCucumberAdapter.addTestStepLog("App is successfully opened.");
    }

    @And("go to call list")
    public void goToCallList() {
        realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/callsHistoryFragment")).click();

        ExtentCucumberAdapter.addTestStepLog("Navigated to call list successfully.");
    }

    @And("click new call button")
    public void clickNewCallButton() {
        realDeviceDriver1.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/fab_empty")).click();
//        realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/fab_new_call")).click();

        ExtentCucumberAdapter.addTestStepLog("Clicked new call button.");

    }

//    @And("make call")
//    public void makeCall() {
//        realDeviceDriver1.findElement(By.xpath("(//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/voiceCall\"])[1]")).click();
//        realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/alertButtonPositive")).click();
//
//
//        ExtentCucumberAdapter.addTestStepLog("Initiating the call...");
//        ExtentCucumberAdapter.addTestStepLog("Call confirmed successfully.");
//    }


    @And("make call")
    public void makeCall() {
        try {
            // Клик по кнопке для звонка
            realDeviceDriver1.findElement(By.xpath("(//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/voiceCall\"])[1]")).click();

            // Подтверждение звонка
            realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/alertButtonPositive")).click();

            // Лог успешного выполнения шага
            ExtentCucumberAdapter.addTestStepLog("Initiating the call...");
            ExtentCucumberAdapter.addTestStepLog("Call confirmed successfully.");
        } catch (Exception e) {
            // Лог ошибки в случае сбоя
            ExtentCucumberAdapter.addTestStepLog("Failed to make call: " + e.getMessage());
        }
    }

    @And("answer the call")
    public void answerTheCall() throws InterruptedException {
        for (int i = 0; i < 5; i++) {
            realDeviceDriver2.openNotifications();

            try {
                WebElement notif1 = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("az.a2z.enigma.v2:id/notifTitle")));
                if (notif1.getText().contains("Test 5002"))
                    realDeviceDriver2.findElement(By.id("az.a2z.enigma.v2:id/button_accept_call")).click();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Xəta: " + e.getMessage(), "XƏTA!", JOptionPane.ERROR_MESSAGE);
            }

            WebElement status1 = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("az.a2z.enigma.v2:id/connectionStatus")));
            sleep(4000);
            if (status1.getText().contains("Qoşuldu")) {
                System.out.println("Zəng qoşuldu");
                realDeviceDriver2.findElement(By.id("az.a2z.enigma.v2:id/hangup")).click();
            } else {
                System.out.println("Zəng qoşulmadı!");
                break;
            }

            WebElement callBtn = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/btnCall\"])[1]")));
            callBtn.click();

            realDeviceDriver1.openNotifications();

            try {
                WebElement notif2 = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.id("az.a2z.enigma.v2:id/notifTitle")));
                if (notif2.getText().contains("AaTest 5001"))
                    realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/button_accept_call")).click();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Xəta: " + e.getMessage(), "XƏTA!", JOptionPane.ERROR_MESSAGE);
            }

            WebElement status2 = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.id("az.a2z.enigma.v2:id/connectionStatus")));
            sleep(4000);
            if (status2.getText().contains("Qoşuldu")) {
                System.out.println("Zəng qoşuldu");
                realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/hangup")).click();
                if (i == 4) break;
            } else {
                System.out.println("Zəng qoşulmadı!");
                break;
            }

            realDeviceDriver1.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            WebElement voiceCall = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/voiceCall\"])[1]")));
            voiceCall.click();
        }
    }



    @And("check the buttons")
    public void checkTheButtons() {
        try {
            // Устанавливаем таймаут для ожиданий
            WebDriverWait wait = new WebDriverWait(realDeviceDriver1, Duration.ofSeconds(15));

            // Нажимаем на кнопку нового вызова
//            WebElement newCallButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("az.a2z.enigma.v2:id/fab_empty")));
//            newCallButton.click();
//            ExtentCucumberAdapter.addTestStepLog("Clicked new call button.");
//            System.out.println("Clicked new call button.");

            // Проверяем состояние динамика (speaker)
            WebElement speakerCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.CheckBox[@resource-id=\"az.a2z.enigma.v2:id/sound\"]")));
            if (speakerCheckbox.isSelected()) {
                ExtentCucumberAdapter.addTestStepLog("Speaker is working: succesful");
            } else {
                ExtentCucumberAdapter.addTestStepLog("Speaker is not working: not succesful");
            }

            // Проверяем состояние микрофона (microphone)
            WebElement microphoneCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.CheckBox[@resource-id=\"az.a2z.enigma.v2:id/microphone\"]")));
            if (microphoneCheckbox.isSelected()) {
                ExtentCucumberAdapter.addTestStepLog("Microphone is working: succesful");
            } else {
                ExtentCucumberAdapter.addTestStepLog("Microphone is not working: not succesful");
            }

            // Завершаем вызов
//            WebElement cancelCallButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/hangup\"]")));
//            cancelCallButton.click();
//            ExtentCucumberAdapter.addTestStepLog("Call has been canceled.");
//            System.out.println("Call has been canceled.");

        } catch (TimeoutException e) {
            // Обрабатываем случай, если элемент не найден в течение 15 секунд
            ExtentCucumberAdapter.addTestStepLog("Error: Element was not found within 15 seconds. " + e.getMessage());
            System.out.println("Error: Element was not found within 15 seconds. " + e.getMessage());
        } catch (NoSuchElementException e) {
            // Обрабатываем случай, если элемент отсутствует
            ExtentCucumberAdapter.addTestStepLog("Error: Unable to find element. " + e.getMessage());
            System.out.println("Error: Unable to find element. " + e.getMessage());
        } catch (Exception e) {
            // Обработка любых других исключений
            ExtentCucumberAdapter.addTestStepLog("Unexpected error: " + e.getMessage());
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }


    @And("check the reconnection")
    public void checkTheReconnection() throws InterruptedException {
//        sleep(30000);
//
//        ConnectionState state;
//        for (int i = 0; i < 4; i++) {
//            state = new ConnectionStateBuilder().withWiFiDisabled().build();
//            realDeviceDriver1.setConnection(state);
//            sleep(20000);
//
//            state = new ConnectionStateBuilder().withWiFiEnabled().build();
//            realDeviceDriver1.setConnection(state);
//            sleep(20000);
//        }
    }

    @And("hang up and recall")
    public void hangUpAndRecall() throws InterruptedException {
//        WebDriverWait wait = new WebDriverWait(realDeviceDriver2, Duration.ofSeconds(10));
//        WebElement status = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("az.a2z.enigma.v2:id/connectionStatus")));
//        if (status.getText().contains("Qoşuldu")) {
//            System.out.println("Zəng qoşuldu");
//            realDeviceDriver2.findElement(By.id("az.a2z.enigma.v2:id/hangup")).click();
//            sleep(2000);
//        }
//
//        realDeviceDriver2.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
//        realDeviceDriver2.findElement(By.xpath("//androidx.recyclerview.widget.RecyclerView[@resource-id=\"az.a2z.enigma.v2:id/chatsRV\"]/android.view.ViewGroup[1]")).click();
//
//        realDeviceDriver2.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
//        realDeviceDriver2.findElement(By.id("az.a2z.enigma.v2:id/m_voice_call")).click();
//        realDeviceDriver2.findElement(By.id("az.a2z.enigma.v2:id/alertButtonPositive")).click();
    }

    @And("first device answers")
    public void firstDeviceAnswers() throws InterruptedException {
//        realDeviceDriver1.openNotifications();
//
//        sleep(4000);
//        PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
//        Sequence tap = new Sequence(finger, 1);
//
//        int x = 750;
//        int y = 880;
//
//        tap.addAction(finger.createPointerMove(Duration.ofMillis(0), PointerInput.Origin.viewport(), x, y));
//        tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
//        tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
//
//        realDeviceDriver1.perform(Arrays.asList(tap));
//
//        sleep(30000);
//        realDeviceDriver1.findElement(By.id("az.a2z.enigma.v2:id/hangup")).click();
    }



    @And("click video call button")
    public void clickVideoCallButton() throws InterruptedException {
        try {
            WebDriverWait wait = new WebDriverWait(realDeviceDriver1, Duration.ofSeconds(15));

            // Клик по кнопке видеозвонка
            WebElement videoCallButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/videoCall\"])[1]")));
            videoCallButton.click();
            ExtentCucumberAdapter.addTestStepLog("Video call button clicked: is working");

            // Клик по подтверждающей кнопке
            WebElement confirmButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.widget.Button[@resource-id=\"az.a2z.enigma.v2:id/alertButtonPositive\"]")));
            confirmButton.click();
            ExtentCucumberAdapter.addTestStepLog("Confirm button clicked: is working");

            // Проверка и переключение камеры
            WebElement cameraCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.CheckBox[@resource-id=\"az.a2z.enigma.v2:id/camera\"]")));
            if (cameraCheckbox.isSelected()) {
                ExtentCucumberAdapter.addTestStepLog("Camera is ON: is working");
            } else {
                cameraCheckbox.click();
                ExtentCucumberAdapter.addTestStepLog("Camera switched ON: is working");
            }

            // Проверка видео
            WebElement videoSwitch = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/video\"]")));
            if (videoSwitch.isDisplayed()) {
                ExtentCucumberAdapter.addTestStepLog("Video is ON: is working");
            } else {
                videoSwitch.click();
                ExtentCucumberAdapter.addTestStepLog("Video switched ON: is working");
            }

            // Проверка микрофона
            WebElement microphoneCheckbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.CheckBox[@resource-id=\"az.a2z.enigma.v2:id/microphone\"]")));
            if (microphoneCheckbox.isSelected()) {
                ExtentCucumberAdapter.addTestStepLog("Microphone is ON: is working");
            } else {
                microphoneCheckbox.click();
                ExtentCucumberAdapter.addTestStepLog("Microphone switched ON: is working");
            }

            // Завершение вызова
            WebElement hangupButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.widget.ImageView[@resource-id=\"az.a2z.enigma.v2:id/hangup\"]")));
            hangupButton.click();
            ExtentCucumberAdapter.addTestStepLog("Call ended: is working");

        } catch (TimeoutException e) {
            ExtentCucumberAdapter.addTestStepLog("Error: Element was not found within 15 seconds. " + e.getMessage());
            System.out.println("Error: Element was not found within 15 seconds. " + e.getMessage());
        } catch (NoSuchElementException e) {
            ExtentCucumberAdapter.addTestStepLog("Error: Unable to find element. " + e.getMessage());
            System.out.println("Error: Unable to find element. " + e.getMessage());
        } catch (Exception e) {
            ExtentCucumberAdapter.addTestStepLog("Unexpected error: " + e.getMessage());
            System.out.println("Unexpected error: " + e.getMessage());
        }
    }
}




//   VIDEO CALL



